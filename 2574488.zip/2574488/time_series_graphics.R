
install.packages("fpp2")
install.packages("ggplot2")
library("fpp2")




# Importing a data set
library("xlsx")
my_data<-read.xlsx("8501011.xls", 2, header=TRUE, startRow=10 )
y<-ts(my_data["A3349468W"] ,start=c(1982,04),frequency = 12)

#Question 2

autoplot(y)+ggtitle("Turnover ;  New South Wales ;  Furniture, floor coverings, houseware and textile goods retailing")+ ylab("$Million")+xlab("Year")

#Question 3

ggseasonplot(y, year.labels = TRUE, year.labels.left = TRUE) + ylab("$Millions")+ ggtitle ("Turnover ;  New South Wales ;  Furniture, floor coverings, houseware and textile goods retailing")
 

#Question 4

ggAcf(y,plot = TRUE)+ggtitle("Yearly Sales")

ggAcf(y,plot = FALSE)


#Question 5 

lambda<- BoxCox.lambda(y)
w<-BoxCox(y,lambda)
autoplot(BoxCox(y,lambda))
autoplot(w)+ ggtitle("Box Test") 

#Question 6

mydata.train <- window(y, start=c(2000,1), end=c(2018,12))
mydata.test <- window(y, start=2019)


#Question 7 

autoplot(y) +
  autolayer(mydata.train, series="Training") +
  autolayer(mydata.test, series="Test")+ ggtitle("Training Set and Test Set from Sales Data")+
  xlab("Year")+ylab("$Millions")
  

# QUESTION 8  compute residuals over training set

#Residuals
resmean<-residuals(meanf(mydata.train))
resnaive<-residuals(naive(mydata.train))
ressnaive<-residuals(snaive(mydata.train))
resdrift<-residuals(rwf(mydata.train, drift=TRUE))

#Forecast over training set
yhat1 <-mydata.train - residuals(meanf(mydata.train))
yhat2 <- mydata.train - residuals(naive(mydata.train))
yhat3 <-mydata.train - residuals(snaive(mydata.train))
yhat4 <-mydata.train - residuals((rwf(mydata.train, drift=TRUE)))


#Check Residuals 
checkresiduals(resmean, lag, df= 24)+ ggtitle("Residuals from Mean")
checkresiduals(resnaive, lag, df= 24)+ggtitle("Residuals from Naive")
checkresiduals(ressnaive, lag, df= 24)+ggtitle("Residuals from Seasonal Naive")
checkresiduals(resdrift, lag, df= 24)+ggtitle("Residuals from Drift")


#All forecasts on Training plot plot
autoplot(y) +
  autolayer(yhat1, series = "Mean")+
  autolayer(yhat2, series= "Naive") +
  autolayer(yhat3, series= "Seasonal Naive") +
  autolayer(yhat4, series = "Drift") +
  autolayer(mydata.train, series="Training Data")+
  ggtitle("Forecasts for Training Data Sales") +
  xlab("Year") + ylab("$Million") +
  guides(colour=guide_legend(title="Forecast"))

#Portmanteau Test 

Box.test(resmean, lag= 24, fitdf=1, type="Ljung-Box")

forecastmean<- meanf(mydata.train,h=27)
forecastnaive <- rwf(mydata.train, h=27)
forecastsnaive <- snaive(mydata.train, h=27)
forecastdrift <- rwf(mydata.train, drift=TRUE, h=27)

autoplot(y)+ 
  autolayer(mydata.test, series = "Test Data")+
  autolayer(forecastmean$mean, series= "Mean")+
  autolayer(forecastnaive$mean, series= "Naive")+
  autolayer(forecastsnaive$mean, series = "Seasonal Naive")+
  autolayer(forecastdrift$mean, series = "Drift")+
  ggtitle("Forecasts")+ xlab("Year")+ylab("Sales")
  guides(colour=guide_legend(title="Forecast"))

  autoplot(mydata.train) +
    autolayer(ymean$mean)+
    autolayer(yhat2, series= "Naive") +
    autolayer(yhat3, series= "Seasonal Naive") +
    autolayer(yhat4, series = "Drift") +
    autolayer(mydata.train, series="Training Data")
  ggtitle("Forecasts for quarterly beer production") +
    xlab("Year") + ylab("Sales") +
    guides(colour=guide_legend(title="Forecast"))
  


